<?php

	session_start();
	// initialize variables
	$id = 0;
	$name = "";
	$address = "";
	$phoneNumber = "";
	$date = "";
	$category = "";
	$update_state = false;
	

	// connect to database
	$db = mysqli_connect('localhost','root','','dbjax');

	//if submit btn is clicked
	if (isset($_POST['save'])) {
		$name = $_POST['name'];
		$address = $_POST['address'];
		$phoneNumber = $_POST['phoneNumber'];
		$date = $_POST['date'];
		$category = $_POST['category'];

		$query = "INSERT INTO appointments (name, address, phoneNumber, date, category) VALUES ('$name', '$address', '$phoneNumber', '$date', '$category')";
		mysqli_query($db, $query);
		$_SESSION['msg'] = "Appointment Saved";
		header('location: jax.php'); // redirect after inserting
	}

	// update records
	if (isset($_POST['update'])) {
		$id = mysql_real_escape_string($_POST['id']);
		$name = mysql_real_escape_string($_POST['name']);
		$address = mysql_real_escape_string($_POST['address']);
		$phoneNumber = mysql_real_escape_string($_POST['phoneNumber']);
		$date = mysql_real_escape_string($_POST['date']);
		$category = mysql_real_escape_string($_POST['category']);

		mysqli_query($db, "UPDATE appointments SET name='$name', address='$address', phoneNumber='$phoneNumber', date='$date', category='$category' WHERE id=$id");
		$_SESSION['msg'] = "Appointment Updated";
		header('location: jax.php');
	}

	// delete records
	if (isset($_GET['del'])) {
		$id = $_GET['del'];
		mysqli_query($db, "DELETE FROM appointments WHERE id=$id");
		$_SESSION['msg'] = "Appointment Deleted";
		header('location: jax.php');
	}

	// retrieve recrds
	$results = mysqli_query($db, "SELECT * FROM appointments");

?>
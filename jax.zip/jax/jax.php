<?php include_once('jax_server.php'); 

	// fetch the record to be uploaded
	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$update_state = true;

		$rec = mysqli_query($db, "SELECT * FROM appointments WHERE id=$id");
		$record = mysqli_fetch_array($rec);
		$id = $record['id'];
		$name = $record['name'];
		$address = $record['address'];
		$phoneNumber = $record['phoneNumber'];
		$date = $record['date'];
		$category = $record['category'];

	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Appointment Setter</title>
	<meta charset="utf-8">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/jax.css">
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
	
	<div class="container-fluid">
		<div class="panel">
			<h3>JAX Medical Hospital</h3>
	</div>
		<?php if (isset($_SESSION['msg'])): ?>
			<div class="msg">
				<?php
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				?>
			</div>
		<?php endif ?>

		
			<div>
				<table class="table table-striped table-bordered">
					<thead>
						<tr>
							<th>Name</th>
							<th>Address</th>
							<th>Phone Number</th>
							<th>Date</th>
							<th>Category</th>
							<th colspan="2">Actions</th>
						</tr>
					</thead>
					<tbody>

						<?php while ($row = mysqli_fetch_array($results)) { ?>
							<tr>
								<td><?php echo $row['name']; ?></td>
								<td><?php echo $row['address']; ?></td>
								<td><?php echo $row['phoneNumber']; ?></td>
								<td><?php echo $row['date']; ?></td>
								<td><?php echo $row['category']; ?></td>
								<td>
									<a class="edit_btn" href="jax.php?edit=<?php echo $row['id']; ?>">Edit</a>
									<a class= "del_btn" href="jax_server.php?del=<?php echo $row['id']; ?>">Delete</a>
								</td>
							</tr>
						<?php } ?>

					</tbody>
				</table>
			</div>
			<div >
			<form class="form" method="post" action="jax_server.php">
			<input type="hidden" name="id" value="<?php echo $id; ?>">
				<div class="input-group">
					<label>Name</label>
					<input type="text" name="name" value="<?php echo $name; ?>" placeholder="Combination of letters and characters" required>
				</div>
				<div class="input-group">
					<label>Address</label>
					<input type="text" name="address" value="<?php echo $address; ?>" placeholder="Combination of letters, characters, and numbers" required>
				</div>
				<div class="input-group">
					<label>Phone Number</label>
					<input type="number" name="phoneNumber" value="<?php echo $phoneNumber; ?>" placeholder="+639000000000" required>
				</div>
				<div class="input-group">
					<label>Date</label>
					<input id="date" type="date" name="date" value="<?php echo $date; ?>" required>
				</div>
				<div class="input-group">
					<label>Category</label>
	                <select id="category" type="text" name="category" value="<?php echo $category; ?>" required>
	                	<option></option>
						<option value="Gynecology"> Gynecology </option>
						<option value="Rehabilitation"> Rehabilitation </option>
						<option value="Psychiatry"> Psychiatry </option>
						<option value="Heart and Vascular Progressive Care Unit"> Heart and Vascular Progressive Care Unit </option>
						<option value="Orthopedics"> Orthopedics </option>
	                </select>
				</div>
				<div class="input-group">
				<?php if ($update_state == false): ?>
					<button type="submit" name="save" class="btn">Submit</button>
				<?php else: ?>
					<button type="submit" name="update" class="btn">Update</button>
				<?php endif ?>

				</div>
			</form>
		</div>
		</div>
</body>
</html>